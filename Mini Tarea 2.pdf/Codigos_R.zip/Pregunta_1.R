library(readxl)
library(pwr)
library(dplyr)

df <- read_excel("dataset_ProblemSet_v2.xls")

#1. Assume that Rich Mantle’s statements are true. For which of the employ-
#ees is it more likely that a hypothesis test will find a statistically significant
#effect of vacations on call service times? Justify your answer. (Hint: think
# about the statistical power of the test).

pwr.t.test(n= NULL, d = .5, sig.level = 0.05, power=.8, type = "two.sample", alternative = "greater")
#power = probabilidad de rechazar H0 dado que es falsa (probabilidad de no cometer error tipo ll)

# Nombres
employees = unique(df$name)

df$pre_holiday = 1
df$lazy_week = 0
#Si mayor o igual a vacaciones then vacaciones
df$pre_holiday[df$week>df$holiday_week] = 0
df$lazy_week[df$week == df$holiday_week + 1] = 1


df %>% 
  group_by(name) %>% 
  summarize(mean = mean(duration),
            sum_pre_holiday = sum(pre_holiday),
            sum_lazy_week = sum(lazy_week),
            cuenta = length(duration))

#### Graficar distribucion normal

#### t statistics
estadisticos = NULL
for(x in 1:length(employees)){
  pre = subset(df$duration, df$name==employees[x] & df$lazy_week==0 & df$week != df$holiday_week)
  post = subset(df$duration, df$name==employees[x] & df$lazy_week==1)
  estadistico = t.test(post, pre, alternative = "greater", var.equal = TRUE)
  delta_medias = mean(pre) - mean(post)
  degrees_freedom =  estadistico[['parameter']]
  pvalue = estadistico[['p.value']]
  estadistico <- estadistico[['statistic']]
  temp = cbind(employees[x],estadistico,degrees_freedom, pvalue, mean(pre), mean(post), delta_medias, sd(pre), sd(post))
  estadisticos = rbind(estadisticos,temp)}


estadisticos = as.data.frame(estadisticos)

### 1.3 SEXOS
test.proporciones <- function(x1,x2){
  tasa_x1 = mean(x1)
  tasa_x2 = mean(x2)
  z_statistic = (tasa_x1-tasa_x2)/sqrt((tasa_x1*(1-tasa_x1))/length(x1) + (tasa_x2*(1-tasa_x2))/length(x2))
  
  return(z_statistic)
    }

estadistico_sex=NULL
mujeres = subset(df$failure, df$name=='Marta' | df$name=='Francisca')
hombres = subset(df$failure, df$name=='Tomas' | df$name=='Javier'| df$name=='Felipe')

temp = cbind(estadistico_sex,degrees_freedom, pvalue, mean(pre), mean(post), delta_medias, sd(pre), sd(post))

estadistico_sex = rbind(estadistico_sex,temp)
estadistico_sex = as.data.frame(estadistico_sex)


#### 1.4
proba <- function(dataset){
  return( pnorm(7, mean=mean(dataset), sd=sd(dataset)/sqrt(length(dataset)), lower.tail=TRUE) - pnorm(0.25, mean=mean(dataset), sd=sd(dataset)/sqrt(length(dataset)), lower.tail=TRUE) ) }

probs = NULL
for(x in 1:length(employees)){
  pre = subset(df$duration, df$name==employees[x] & df$lazy_week==0 & df$week != df$holiday_week)
  post = subset(df$duration, df$name==employees[x] & df$lazy_week==1)
  temp = cbind(employees[x],proba(pre),proba(post), length(pre), length(post), shapiro.test(pre)[['p.value']], shapiro.test(post)[['p.value']])
  probs = rbind(probs,temp)}


probs = as.data.frame(probs)
