library(readxl)

df_original <- read_excel("~/Documents/Seminario de investigacion ii/Tarea 2/surgery data.xlsx")


### PRIMERAS PREGUNTAS
df<- df_original[1:34,c('OR Time Actual')]

#Pregunta 1
#1. Estimate the average duration of a cardiac surgery. Compute the standard error of your estimate.
media = mean(df$`OR Time Actual`)
error_estandar = sd(df$`OR Time Actual`)/sqrt(length(df$`OR Time Actual`))
resultado_p1 = cbind(media, error_estandar)
resultado_p1 = as.data.frame(resultado_p1)
colnames(resultado_p1) = c('Media', 'Error Estándar')

#2. Provide a 95% confidence interval for the average surgery duration, assuming that surgery duration follows a Normal distribution.
ci = cbind(media + error_estandar * qnorm(.025,lower.tail=TRUE) , media + error_estandar * qnorm(.025,lower.tail=FALSE) )
resultado_p2 = as.data.frame(ci)
colnames(resultado_p2) = c('Límite Inferior', 'Límite Superior')

#3. What is the probability that a surgery takes more than 6 hours? more than 8 hours? Provide an answer assuming that surgery duration follows a Normal distribution.
#3.1 What is the probability that a surgery takes more than 6 hours?
resultado_p3_1 = pnorm(6*60, mean = media, sd = sd(df$`OR Time Actual`), lower.tail = FALSE)
#3.2 What is the probability that a surgery takes more than 8 hours?
resultado_p3_2 = pnorm(8*60, mean = media, sd = sd(df$`OR Time Actual`), lower.tail = FALSE)

resultado_p3 = cbind(resultado_p3_1, resultado_p3_2)
resultado_p3 = as.data.frame(resultado_p3)
colnames(resultado_p3) = c('Probabilidad mayor a 6 hrs', 'Probabilidad mayor a 8 hrs')

#4. Use a qq-plot to assess whether surgery durations follow a Normal distribution.
qqnorm(df$`OR Time Actual`)
qqline(df$`OR Time Actual`)
      # Se aleja de la normal hacia los extremos

#5. 5. Suppose that surgeries do not follow a Normal distribution. Respond question 3 using the empirical distribution of surgery durations.
distribucion_empirica = ecdf(df$`OR Time Actual`)
plot(distribucion_empirica)
#5.1 What is the probability that a surgery takes more than 6 hours?
resultado_p5_1 = length(df$`OR Time Actual`[df$`OR Time Actual`>6*60])/length(df$`OR Time Actual`)
#5.2 What is the probability that a surgery takes more than 8 hours?
resultado_p5_2 = length(df$`OR Time Actual`[df$`OR Time Actual`>8*60])/length(df$`OR Time Actual`)

resultado_p5 = cbind(resultado_p5_1, resultado_p5_2)
resultado_p5 = as.data.frame(resultado_p5)
colnames(resultado_p5) = c('Probabilidad mayor a 6 hrs', 'Probabilidad mayor a 8 hrs')

### PREGUNTAS 6 y 7
df<- df_original[,c('OR Time Actual', 'OR Time Estimate', 'Emergency', 'AGE')]

#6. The schedule of surgeries is overrun when the duration of the surgery (OR Time Actual) exceeds the allocated time for the surgery (OR Time Estimate). Conduct a hypothesis test to assess whether emergencies and elective (non-emergency) cases differ in their overrun probabilities.

#7
# PRIMERO ANOVA, si son iguales hare 3 t
df$AGE_PRIMA = 'baby'
df$AGE_PRIMA[df$AGE>=51]='normal'
df$AGE_PRIMA[df$AGE>=71]='old'
df$duration = df$`OR Time Actual`

dat.aov <- aov(duration ~ AGE_PRIMA, data=df)
summary(dat.aov)
####  Pr(>F) es el valor p
      ## No se rechaza que sean iguales