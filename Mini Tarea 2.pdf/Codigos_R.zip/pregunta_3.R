library(readxl)
library(ggplot2)

data <- read_excel("~/Documents/Seminario de investigacion ii/Tarea 2/AER20081092_Data.xls")

# Quedarse pre 2003
df <- subset(data, data$Year <= 2003)

df$first_team = 0
df$second_team = 0
df$first_team[df$Win == 1] = mean(df$Win)/sum(df$Win)
df$second_team[df$Win == 0] = (1-mean(df$Win))/(nrow(df) - sum(df$Win))


first_team = mean(df$Win)
second_team = 1 - mean(df$Win)

winnings = cbind(first_team, second_team)
winnings = as.data.frame(winnings)

##### 3.2
### one sample proportion test
osproptest <- function(vector,nula){
  numerador = mean(vector)-nula
  denominador = mean(vector)*(1-mean(vector))/length(vector)
  return(numerador/sqrt(denominador))
}

#Test bajo distribucion normal
1 - (pnorm(osproptest(df$Win, 0.5), lower.tail = TRUE) - pnorm(osproptest(df$Win, 0.5), lower.tail = FALSE))

#Test binomial exacto
binom.test(sum(df$Win), length(df$Win), p = 0.5, alternative = "two.sided")

#Test bajo distribucion chi cuadrado
prop.test(sum(df$Win), length(df$Win), p = 0.5, alternative = "two.sided", correct = FALSE)


#### PREGUNTA 3.3
library(pwr)

# Chi cuadrado
suma = 0
for(valor in df$Win){
  suma = suma + ((valor - 0.5)^2)/0.5
}

pwr.chisq.test(w = suma, N = length(df$Win), df =1 , sig.level =0.05, power = NULL) 

# Normal y Binomial

p=0.6
p0=0.5
alpha=0.05
n = length(df$Win)
z=(p-p0)/sqrt(p*(1-p)/n)
(Power=pnorm(z-qnorm(1-alpha/2))+pnorm(-z-qnorm(1-alpha/2)))


